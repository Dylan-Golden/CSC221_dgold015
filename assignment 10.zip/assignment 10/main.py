import functions

for i in range(4):
    print (f"TRIAL {i+1}:")

    print ("\nNum:")
    functions.num(i, 2)
    print ("\nNum 2nd number not given:")
    functions.num(i)

    print ("\nVerbose_num True:")
    functions.verbose_num(i, 3, True)
    print ("\nVerbose_num False:")
    functions.verbose_num(i, 3)

help (functions)
help (functions.num)
help (functions.verbose_num)
