'''
  Functions module
  By: Dylan Golden
'''

def num(one, two = 3.14159265):
  ''' takes two numbers and adds them together, if 2nd num
isnt given it is set to pi'''
  num_list = [one, two]
  print (one + two)
  print (sorted(num_list))

def verbose_num(one, two = 3.14159265, verbose=False):
  ''' same as num but only works if verbose is True'''
  if verbose == True:
    num_list = [one, two]
    print (one + two)
    print (sorted(num_list))

''' Test code that will only run if imported'''
if __name__ == '__main__':
    num (1, 2)
    num (1)
    num (2, 1)
    num (5)
    print ("-------------------")
    verbose_num (1, 2, True)
    verbose_num (1)
    verbose_num (2, 1, True)
    verbose_num (5)